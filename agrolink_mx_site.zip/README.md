# AgroLink MX

Prototipo inicial del sistema AgroLink MX — una plataforma para conectar productores agrícolas con compradores nacionales e internacionales usando inteligencia artificial.

## Estructura
- index.html → Sitio principal
- README.md → Información del proyecto

## Cómo desplegar en GitHub Pages
1. Crea un nuevo repositorio público en GitHub.
2. Sube estos archivos.
3. En Settings → Pages, selecciona la rama `main` y carpeta `/root`.
4. Espera unos segundos y accede al enlace generado.
